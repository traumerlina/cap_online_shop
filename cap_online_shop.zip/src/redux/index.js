import { fetchCaps } from "./actions";



import store from "./store";

export { store, fetchCaps};