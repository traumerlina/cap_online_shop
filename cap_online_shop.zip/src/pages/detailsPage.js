
import React from 'react';
import Details from '../components/productMap';

const DetailsPage = () => {
  return (
    <div>
      <Details/>
    </div>
  )
}
export default DetailsPage;

