import HomePage from "./homePage";
import CartPage from "./cartPage";
import CatalogPage from "./catalogPage";
import SearchPage from "./searchPage";

export {HomePage, CartPage,CatalogPage,  SearchPage};