import React from 'react';
import Footer from '../components/footer';
import Caplist from '../components/caplist';




const SearchPage = () => {

  return (
    <div>
      <Caplist/>
      <Footer/>
    </div>
  )
}


export default SearchPage;
