import React from 'react';
import Footer from '../components/footer';
import CartPart from '../components/cartPart/cartPart';


const CartPage = () => {
  return (
    <div>
      <CartPart/>
      
      <Footer/>

    </div>
  )
}

export default CartPage;  