import React from "react";

const CapsContext = React.createContext();

export default CapsContext;